# IP-LAUNCHER

Launcher Android (Kotlin + Jetpack Compose) bergaya iOS: beranda, dock, App Library, dan layar kunci.
Semua ikon dan wallpaper memakai desain orisinal, bukan aset milik Apple.

## Fitur
- Beranda grid 4 kolom + dock + App Library (pencarian)
- **Ikon "palsu"**: nama dan gambar ikon terpisah dari aplikasi tujuan
  (contoh: ikon "App Store" membuka Play Store). Tekan lama ikon untuk mengubahnya.
- Layar kunci gaya iOS (jam besar, senter, kamera, geser untuk membuka)

## Memakai
1. Pasang APK, buka **IP-LAUNCHER Setup**.
2. Tekan **Jadikan beranda bawaan**.
3. (Opsional) aktifkan layar kunci: beri izin overlay + notifikasi, lalu nyalakan saklarnya.

## Batasan
Android tidak mengizinkan aplikasi mengganti layar kunci sistem. Layar kunci gaya iOS tampil lebih dulu,
lalu layar kunci asli HP (PIN/sidik jari) muncul setelah menggeser ke atas.

## Build
Upload folder ini (atau zip-nya) ke GitHub. Workflow `.github/workflows/main.yml` membuat `IP-LAUNCHER-V1.apk`
di tab Actions, bagian Artifacts.
