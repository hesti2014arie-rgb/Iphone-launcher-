package com.iplauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppEntry(
    val label: String,
    val pkg: String,
    val cn: ComponentName,
    val icon: ImageBitmap
)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map {
        AppEntry(
            label = it.loadLabel(pm).toString(),
            pkg = it.activityInfo.packageName,
            cn = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
            icon = it.loadIcon(pm).toBitmap(108, 108).asImageBitmap()
        )
    }.sortedBy { it.label.lowercase() }
}

@Composable
fun IconView(item: HomeItem, size: Dp) {
    val bmp = remember(item.customIcon) {
        item.customIcon?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() }
    }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(percent = 22))
            .background(Brush.verticalGradient(listOf(Color(item.c1), Color(item.c2)))),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(item.emoji, fontSize = (size.value * 0.5f).sp)
        }
    }
}

@Composable
fun Label(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 11.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        style = LocalTextStyle.current.copy(shadow = Shadow(Color(0x99000000), Offset.Zero, 8f))
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GridPage(list: List<HomeItem>, onOpen: (HomeItem) -> Unit, onEdit: (HomeItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        userScrollEnabled = false,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(list, key = { it.id }) { item ->
            Column(
                Modifier.combinedClickable(onClick = { onOpen(item) }, onLongClick = { onEdit(item) }),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconView(item, 62.dp)
                Spacer(Modifier.height(5.dp))
                Label(item.label)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Dock(list: List<HomeItem>, onOpen: (HomeItem) -> Unit, onEdit: (HomeItem) -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .clip(shape)
            .background(Color(0x33FFFFFF))
            .border(1.dp, Color(0x40FFFFFF), shape)
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        list.forEach { item ->
            Box(Modifier.combinedClickable(onClick = { onOpen(item) }, onLongClick = { onEdit(item) })) {
                IconView(item, 62.dp)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PageDots(current: Int, count: Int, onLongPress: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = {}, onLongClick = onLongPress)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        repeat(count) { i ->
            Box(
                Modifier
                    .padding(horizontal = 4.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (i == current) Color.White else Color(0x80FFFFFF))
            )
        }
    }
}

@Composable
fun AppLibraryPage(onSetup: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val apps by produceState(emptyList<AppEntry>()) {
        value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    val shown = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "App Library",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSetup) { Text("Pengaturan", color = Color.White) }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Cari aplikasi") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = Color.White,
                focusedBorderColor = Color(0x80FFFFFF),
                unfocusedBorderColor = Color(0x40FFFFFF),
                focusedPlaceholderColor = Color(0xAAFFFFFF),
                unfocusedPlaceholderColor = Color(0xAAFFFFFF)
            ),
            modifier = Modifier.fillMaxWidth()
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(shown) { app ->
                Column(
                    Modifier.clickable {
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_MAIN)
                                    .addCategory(Intent.CATEGORY_LAUNCHER)
                                    .setComponent(app.cn)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        app.icon, null,
                        Modifier.size(58.dp).clip(RoundedCornerShape(percent = 22))
                    )
                    Spacer(Modifier.height(5.dp))
                    Label(app.label)
                }
            }
        }
    }
}

@Composable
fun EditDialog(
    item: HomeItem,
    onDismiss: () -> Unit,
    onSave: (String, String?) -> Unit,
    onPickImage: () -> Unit,
    onResetIcon: () -> Unit
) {
    val ctx = LocalContext.current
    var label by remember { mutableStateOf(item.label) }
    var pkg by remember { mutableStateOf<String?>(null) }
    var choosing by remember { mutableStateOf(false) }
    val apps by produceState(emptyList<AppEntry>(), choosing) {
        if (choosing) value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }

    val current = pkg ?: when (val t = item.target) {
        is Target.Pkg -> t.name
        else -> "aplikasi bawaan HP (otomatis)"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Atur ikon") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Nama di bawah ikon") },
                    singleLine = true
                )
                Text("Membuka: $current", fontSize = 13.sp)
                Button(onClick = { choosing = true }) { Text("Pilih aplikasi tujuan") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPickImage) { Text("Gambar ikon") }
                    OutlinedButton(onClick = onResetIcon) { Text("Reset ikon") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(label.trim().ifEmpty { item.label }, pkg) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )

    if (choosing) {
        AlertDialog(
            onDismissRequest = { choosing = false },
            title = { Text("Pilih aplikasi tujuan") },
            text = {
                LazyColumn(Modifier.height(380.dp)) {
                    items(apps) { app ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { pkg = app.pkg; choosing = false }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(app.icon, null, Modifier.size(36.dp).clip(RoundedCornerShape(percent = 22)))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(app.label)
                                Text(app.pkg, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { choosing = false }) { Text("Tutup") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: LauncherViewModel = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState { 2 }
    var editing by remember { mutableStateOf<HomeItem?>(null) }
    var pickingFor by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val id = pickingFor
        if (uri != null && id != null) vm.setIconFromUri(id, uri)
    }

    BackHandler(enabled = pager.currentPage != 0) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    val open: (HomeItem) -> Unit = { item ->
        if (!launchTarget(ctx, item.target)) {
            Toast.makeText(ctx, "Aplikasi tujuan tidak ditemukan. Tekan lama ikon untuk mengatur.", Toast.LENGTH_SHORT).show()
        }
    }
    val openSetup: () -> Unit = {
        ctx.startActivity(Intent(ctx, SetupActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    val grid = vm.items.filter { it.id !in Defaults.dockIds }
    val dock = Defaults.dockIds.mapNotNull { id -> vm.items.firstOrNull { it.id == id } }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            if (page == 0) GridPage(grid, open) { editing = it }
            else AppLibraryPage(openSetup)
        }
        PageDots(pager.currentPage, 2, openSetup)
        Dock(dock, open) { editing = it }
        Spacer(Modifier.height(8.dp))
    }

    editing?.let { item ->
        EditDialog(
            item = item,
            onDismiss = { editing = null },
            onSave = { label, pkg -> vm.setLabelTarget(item.id, label, pkg); editing = null },
            onPickImage = { pickingFor = item.id; editing = null; picker.launch("image/*") },
            onResetIcon = { vm.resetIcon(item.id); editing = null }
        )
    }
}
