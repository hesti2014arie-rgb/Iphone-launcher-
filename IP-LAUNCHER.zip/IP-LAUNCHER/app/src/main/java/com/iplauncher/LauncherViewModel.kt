package com.iplauncher

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("ipl", Context.MODE_PRIVATE)

    val items = mutableStateListOf<HomeItem>().apply {
        addAll(Defaults.all.map { withOverrides(it) })
    }

    private fun withOverrides(i: HomeItem): HomeItem {
        val label = prefs.getString("label_${i.id}", null) ?: i.label
        val pkg = prefs.getString("pkg_${i.id}", null)
        val icon = prefs.getString("icon_${i.id}", null)?.takeIf { File(it).exists() }
        return i.copy(
            label = label,
            target = if (pkg != null) Target.Pkg(pkg) else i.target,
            customIcon = icon
        )
    }

    private fun replace(id: String, f: (HomeItem) -> HomeItem) {
        val idx = items.indexOfFirst { it.id == id }
        if (idx >= 0) items[idx] = f(items[idx])
    }

    fun setLabelTarget(id: String, label: String, pkg: String?) {
        val e = prefs.edit()
        e.putString("label_$id", label)
        if (pkg != null) e.putString("pkg_$id", pkg)
        e.apply()
        replace(id) { it.copy(label = label, target = if (pkg != null) Target.Pkg(pkg) else it.target) }
    }

    fun setIconFromUri(id: String, uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val src = app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return@launch
                val s = minOf(src.width, src.height)
                val crop = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
                val out = Bitmap.createScaledBitmap(crop, 256, 256, true)
                val file = File(app.filesDir, "icon_${id}_${System.currentTimeMillis()}.png")
                file.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                prefs.getString("icon_$id", null)?.let { File(it).delete() }
                prefs.edit().putString("icon_$id", file.absolutePath).apply()
                withContext(Dispatchers.Main) { replace(id) { it.copy(customIcon = file.absolutePath) } }
            } catch (_: Exception) {
            }
        }
    }

    fun resetIcon(id: String) {
        prefs.getString("icon_$id", null)?.let { File(it).delete() }
        prefs.edit().remove("icon_$id").apply()
        replace(id) { it.copy(customIcon = null) }
    }
}
