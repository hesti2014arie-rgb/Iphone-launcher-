package com.iplauncher

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings

/** Aplikasi tujuan saat ikon dibuka. */
sealed interface Target {
    data class Pkg(val name: String) : Target
    data class Category(val cat: String) : Target
    data class Action(val action: String) : Target
}

/** Ikon "palsu": tampilan (label, gambar) terpisah dari aplikasi yang dibuka. */
data class HomeItem(
    val id: String,
    val label: String,
    val emoji: String,
    val c1: Long,
    val c2: Long,
    val target: Target,
    val customIcon: String? = null
)

object Defaults {
    val dockIds = listOf("phone", "safari", "messages", "music")

    val all = listOf(
        HomeItem("calendar", "Calendar", "📅", 0xFFFFFFFF, 0xFFE9E9EE, Target.Category(Intent.CATEGORY_APP_CALENDAR)),
        HomeItem("photos", "Photos", "🌸", 0xFFFFFFFF, 0xFFF1E4F7, Target.Category(Intent.CATEGORY_APP_GALLERY)),
        HomeItem("camera", "Camera", "📷", 0xFF9A9AA0, 0xFF48484A, Target.Action(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
        HomeItem("maps", "Maps", "🗺️", 0xFF8EE6A0, 0xFF2BA84A, Target.Category(Intent.CATEGORY_APP_MAPS)),
        HomeItem("clock", "Clock", "🕒", 0xFF2C2C2E, 0xFF000000, Target.Action(AlarmClock.ACTION_SHOW_ALARMS)),
        HomeItem("weather", "Weather", "⛅", 0xFF5AC8FA, 0xFF1C6EF2, Target.Pkg("com.google.android.apps.weather")),
        HomeItem("notes", "Notes", "📝", 0xFFFFE066, 0xFFFFC107, Target.Pkg("com.google.android.keep")),
        HomeItem("wallet", "Wallet", "💳", 0xFF3A3A3C, 0xFF000000, Target.Pkg("com.google.android.apps.walletnfcrel")),
        HomeItem("appstore", "App Store", "🛍️", 0xFF4FC3F7, 0xFF1565FF, Target.Pkg("com.android.vending")),
        HomeItem("settings", "Settings", "⚙️", 0xFFA6A6AB, 0xFF636366, Target.Action(Settings.ACTION_SETTINGS)),
        HomeItem("mail", "Mail", "✉️", 0xFF4FC3F7, 0xFF1976D2, Target.Category(Intent.CATEGORY_APP_EMAIL)),
        HomeItem("calc", "Calculator", "➗", 0xFF636366, 0xFF2C2C2E, Target.Category(Intent.CATEGORY_APP_CALCULATOR)),
        HomeItem("contacts", "Contacts", "👤", 0xFFC7C7CC, 0xFF8E8E93, Target.Category(Intent.CATEGORY_APP_CONTACTS)),
        HomeItem("files", "Files", "📁", 0xFF4FC3F7, 0xFF1565FF, Target.Pkg("com.google.android.apps.nbu.files")),
        HomeItem("health", "Health", "❤️", 0xFFFFFFFF, 0xFFFFE0E6, Target.Pkg("com.google.android.apps.fitness")),
        // dock
        HomeItem("phone", "Phone", "📞", 0xFF6EE08A, 0xFF1FA13F, Target.Action(Intent.ACTION_DIAL)),
        HomeItem("safari", "Safari", "🧭", 0xFF5AC8FA, 0xFF1C6EF2, Target.Category(Intent.CATEGORY_APP_BROWSER)),
        HomeItem("messages", "Messages", "💬", 0xFF6EE08A, 0xFF1FA13F, Target.Category(Intent.CATEGORY_APP_MESSAGING)),
        HomeItem("music", "Music", "🎵", 0xFFFF6B8A, 0xFFE0243F, Target.Category(Intent.CATEGORY_APP_MUSIC))
    )
}

/** Membuka aplikasi tujuan. Mengembalikan false jika tidak ditemukan. */
fun launchTarget(ctx: Context, t: Target): Boolean {
    val intent: Intent = when (t) {
        is Target.Pkg -> ctx.packageManager.getLaunchIntentForPackage(t.name)
        is Target.Category -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, t.cat)
        is Target.Action -> Intent(t.action)
    } ?: return false
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}
