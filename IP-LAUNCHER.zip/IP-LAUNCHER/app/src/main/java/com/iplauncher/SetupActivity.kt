package com.iplauncher

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class SetupActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { SetupScreen() }
        }
    }
}

@Composable
fun SetupScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ipl", 0) }
    var lockOn by remember { mutableStateOf(prefs.getBoolean("lock_on", false)) }
    var overlay by remember { mutableStateOf(Settings.canDrawOverlays(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            overlay = Settings.canDrawOverlays(ctx)
            delay(1000)
        }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("IP-LAUNCHER", style = MaterialTheme.typography.headlineMedium)

            Text("Beranda", style = MaterialTheme.typography.titleMedium)
            Text("Jadikan IP-LAUNCHER aplikasi beranda bawaan agar tampilannya aktif.")
            Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }) {
                Text("Jadikan beranda bawaan")
            }

            HorizontalDivider()

            Text("Layar kunci gaya iOS", style = MaterialTheme.typography.titleMedium)
            Text(
                "Layar ini tampil lebih dulu saat layar menyala. Layar kunci asli HP " +
                    "(PIN, pola, atau sidik jari) tetap ada dan muncul setelah kamu menggeser ke atas."
            )
            Button(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }) {
                Text(if (overlay) "✔ Izin tampil di atas aplikasi lain" else "1. Beri izin tampil di atas aplikasi lain")
            }
            if (Build.VERSION.SDK_INT >= 33) {
                OutlinedButton(onClick = { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                    Text("2. Izinkan notifikasi")
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Aktifkan layar kunci", Modifier.weight(1f))
                Switch(
                    checked = lockOn,
                    enabled = overlay,
                    onCheckedChange = { on ->
                        lockOn = on
                        prefs.edit().putBoolean("lock_on", on).apply()
                        val svc = Intent(ctx, LockService::class.java)
                        if (on) ContextCompat.startForegroundService(ctx, svc) else ctx.stopService(svc)
                    }
                )
            }
            OutlinedButton(onClick = { ctx.startActivity(Intent(ctx, LockScreenActivity::class.java)) }) {
                Text("Uji tampilan layar kunci")
            }
            Text(
                "Catatan: matikan penghemat baterai untuk aplikasi ini agar layar kunci tidak berhenti. " +
                    "Layanan perlu dinyalakan lagi setelah HP restart.",
                style = MaterialTheme.typography.bodySmall
            )

            HorizontalDivider()

            Text("Ikon", style = MaterialTheme.typography.titleMedium)
            Text("Di beranda, tekan lama sebuah ikon untuk mengubah nama, gambar, dan aplikasi yang dibuka.")
        }
    }
}
